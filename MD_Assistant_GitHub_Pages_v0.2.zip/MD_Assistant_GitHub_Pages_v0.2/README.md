# MD Assistant — GitHub Pages demonstration (v0.2)

This is a **static, rule-based demonstration**, not a verified AI decision-support engine. It has no server-side authentication, document verification, or authoritative legal-rule retrieval. Do **not** enter confidential, personal, or sensitive official information. Use synthetic examples only.

## Publish using GitHub from an iPad

1. Sign in at https://github.com/new and create a repository named `md-assistant-demo` (choose **Public** for standard GitHub Pages publication).
2. In the repository select **Add file → Upload files**. Upload `index.html` and `README.md` from the Files app. Commit changes.
3. Go to **Settings → Pages**. Under **Build and deployment**, select **Deploy from a branch**, branch `main`, folder `/(root)`, then **Save**.
4. Wait for deployment and open the Pages URL shown in Settings → Pages (normally `https://YOUR_USERNAME.github.io/md-assistant-demo/`).

If uploading individual files from the iPad is difficult, unzip the package in Files first, then upload the two files. Do not upload the ZIP as the only repository file; GitHub Pages needs `index.html` at the publication root.

## Security and scope

- Public Pages hosts the source code publicly. No real government file content should be pasted into this demo.
- Browser local storage, if available, is device/browser-specific and is **not** secure institutional storage.
- This app runs entirely client-side, so it has no external AI integration or secure institutional knowledge sync.
- For real use, deploy a separately secured and authorised service with access controls, audit logs, verified knowledge sources and an approved data-handling arrangement.
